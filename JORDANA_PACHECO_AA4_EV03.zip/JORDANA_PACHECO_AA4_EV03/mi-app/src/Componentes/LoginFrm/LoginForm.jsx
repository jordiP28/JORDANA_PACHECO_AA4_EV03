import React, { useState } from 'react';
import './LoginForm.css';
import { FaUserAlt, FaEnvelope } from 'react-icons/fa';
import { IoMdLock, IoMdPhonePortrait } from 'react-icons/io';
import logo2 from './logo2.PNG';

const LoginForm = () => {
    const [isRegistering, setIsRegistering] = useState(false);

    const handleToggleForm = () => {
        setIsRegistering(!isRegistering);
    };

    return (
        <div className={`container${isRegistering ? ' active' : ''}`}>
            <div className='wrapper'>
                <img src={logo2} alt="Logo de la aplicación" className='app-logo' />
                <form>
                    <h1>Ingreso</h1>
                    <div className='input-box'>
                        <input type='text' placeholder='Usuario' required />
                        <FaUserAlt className='icon' />
                    </div>
                    <div className='input-box'>
                        <input type='password' placeholder='Contraseña' required />
                        <IoMdLock className='icon' />
                    </div>
                    <div className='recuerdame-olvidame'>
                        <label><input type="checkbox" /> Recordarme</label>
                        <a href="#">Olvidaste tu Contraseña</a>
                    </div>
                    <button type='submit'>Ingresar</button>
                    <div className='link-registro'>
                        <p>No tienes cuenta? <a href="#" onClick={handleToggleForm}>Regístrate</a></p>
                    </div>
                </form>
            </div>

            <div className='fox-box'>
                <form>
                    <h1>Regístrate</h1>
                    <div className='input-box'>
                        <input type='text' placeholder='Nombres' required />
                        <FaUserAlt className='icon' />
                    </div>
                    <div className='input-box'>
                        <input type='email' placeholder='Correo' required />
                        <FaEnvelope className='icon' />
                    </div>
                    <div className='input-box'>
                        <input type='text' placeholder='Celular' required />
                        <IoMdPhonePortrait className='icon' />
                    </div>
                    <div className='input-box'>
                        <input type='password' placeholder='Contraseña' required />
                        <IoMdLock className='icon' />
                    </div>
                    <div className='recuerdame-olvidame'>
                        <label><input type="checkbox" /> Acepto los términos y condiciones.</label>
                    </div>
                    <button type='submit'>Registrarme</button>
                    <div className='link-registro'>
                        <p>Ya tengo una cuenta <a href="#" onClick={handleToggleForm}>Ingresar</a></p>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default LoginForm;
