
import LoginForm from './Componentes/LoginFrm/LoginForm';

function App() {
  return (
    <div >
     <LoginForm/>
    </div>
  );
}

export default App;
